package com.cg.movie.exceptions;

public class SongsDetailNotFoundException extends Exception {

	public SongsDetailNotFoundException() {
		super();
		
	}

	public SongsDetailNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public SongsDetailNotFoundException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public SongsDetailNotFoundException(String message) {
		super(message);
		
	}

	public SongsDetailNotFoundException(Throwable cause) {
		super(cause);
		
	}

}
