package com.cg.movie.beans;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Movie {
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
	    private int movieId;
	    private String movieName;
		private String movieBudget;
		private long movieBoxOfficeCollection;
		
		@OneToMany(mappedBy="movie")
		@MapKey
		@JsonIgnore// Most recent
		private Map<Integer,Songs> songs = new HashMap<Integer, Songs>();

		public Movie() {
			super();
		}

		public Movie(int movieId, String movieName, String movieBudget, long movieBoxOfficeCollection,
				Map<Integer, Songs> songs) {
			super();
			this.movieId = movieId;
			this.movieName = movieName;
			this.movieBudget = movieBudget;
			this.movieBoxOfficeCollection = movieBoxOfficeCollection;
			this.songs = songs;
		}

		public Movie(String movieName, String movieBudget, long movieBoxOfficeCollection, Map<Integer, Songs> songs) {
			super();
			this.movieName = movieName;
			this.movieBudget = movieBudget;
			this.movieBoxOfficeCollection = movieBoxOfficeCollection;
			this.songs = songs;
		}

		public int getMovieId() {
			return movieId;
		}

		public void setMovieId(int movieId) {
			this.movieId = movieId;
		}

		public String getMovieName() {
			return movieName;
		}

		public void setMovieName(String movieName) {
			this.movieName = movieName;
		}

		public String getMovieBudget() {
			return movieBudget;
		}

		public void setMovieBudget(String movieBudget) {
			this.movieBudget = movieBudget;
		}

		public long getMovieBoxOfficeCollection() {
			return movieBoxOfficeCollection;
		}

		public void setMovieBoxOfficeCollection(long movieBoxOfficeCollection) {
			this.movieBoxOfficeCollection = movieBoxOfficeCollection;
		}

		public Map<Integer, Songs> getSongs() {
			return songs;
		}

		public void setSongs(Map<Integer, Songs> songs) {
			this.songs = songs;
		}

		
		
		public Movie(String movieName, String movieBudget, long movieBoxOfficeCollection) {
			super();
			this.movieName = movieName;
			this.movieBudget = movieBudget;
			this.movieBoxOfficeCollection = movieBoxOfficeCollection;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + (int) (movieBoxOfficeCollection ^ (movieBoxOfficeCollection >>> 32));
			result = prime * result + ((movieBudget == null) ? 0 : movieBudget.hashCode());
			result = prime * result + movieId;
			result = prime * result + ((movieName == null) ? 0 : movieName.hashCode());
			result = prime * result + ((songs == null) ? 0 : songs.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Movie other = (Movie) obj;
			if (movieBoxOfficeCollection != other.movieBoxOfficeCollection)
				return false;
			if (movieBudget == null) {
				if (other.movieBudget != null)
					return false;
			} else if (!movieBudget.equals(other.movieBudget))
				return false;
			if (movieId != other.movieId)
				return false;
			if (movieName == null) {
				if (other.movieName != null)
					return false;
			} else if (!movieName.equals(other.movieName))
				return false;
			if (songs == null) {
				if (other.songs != null)
					return false;
			} else if (!songs.equals(other.songs))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", movieBudget=" + movieBudget
					+ ", movieBoxOfficeCollection=" + movieBoxOfficeCollection  + "]";
		}
	
	
	
}
