package com.cg.movie.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Songs;
import com.cg.movie.daoservices.MovieDao;
import com.cg.movie.daoservices.SongDao;
import com.cg.movie.exceptions.MovieDetailNotFoundException;
import com.cg.movie.exceptions.SongsDetailNotFoundException;


@Component("movieServices")
public class MovieServicesImpl implements MovieServices {
	@Autowired
	private MovieDao movieDao;
	
	@Autowired
	private SongDao songDao;
	
	@Override
	public Movie acceptMovieDetails(Movie movie) {
	
		movie = movieDao.save(movie);
		return movie;
	}

	@Override
	public Movie getMovieDetails(int movieId) throws MovieDetailNotFoundException {
		
		 return movieDao.findById(movieId).orElseThrow
				 (()->new MovieDetailNotFoundException("Movie details not found for movieId "+movieId));
	}

	@Override
	public List<Movie> getAllMovieDetails() {
		
		return movieDao.findAll();
	}

	@Override
	public boolean removeMovieDetails(int movieId) throws MovieDetailNotFoundException {
		movieDao.delete(getMovieDetails(movieId));
		return true;
	}

	@Override
	public Songs acceptSongsDetails(Songs songs, int movieId) throws MovieDetailNotFoundException {
		Movie movie = movieDao.findById(movieId).orElseThrow(()->new MovieDetailNotFoundException("Movie Id invalid!!!"));
		songs.setMovie(movie);
		songDao.save(songs);
		return songs;
	}

	@Override
	public Songs getSongsDetail(int songId) throws SongsDetailNotFoundException {
		return songDao.findById(songId).orElseThrow
				 (()->new SongsDetailNotFoundException("Songs details not found for songId "+songId));
	}

	@Override
	public List<Songs> getAllSongsDetails() {
		
		return songDao.findAll();
	}

	public boolean removeSongsDetails(int songId) throws SongsDetailNotFoundException {
		songDao.delete(getSongsDetail(songId));
		return true;
	}

	
}
