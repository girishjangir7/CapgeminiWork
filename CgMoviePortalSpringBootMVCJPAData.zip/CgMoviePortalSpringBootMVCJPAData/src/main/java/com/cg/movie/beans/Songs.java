package com.cg.movie.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Songs {
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int songId;
		private String songName;
		private String artist;
		private String duration;
		private String genre;
		
		@ManyToOne
		@JsonIgnore
		private Movie movie;

		public Songs() {
			super();
		}

		
		public Songs(int songId, String songName, String artist, String duration, String genre, Movie movie) {
			super();
			this.songId = songId;
			this.songName = songName;
			this.artist = artist;
			this.duration = duration;
			this.genre = genre;
			this.movie = movie;
		}

		public int getSongId() {
			return songId;
		}

		public void setSongId(int songId) {
			this.songId = songId;
		}

		public String getSongName() {
			return songName;
		}

		public void setSongName(String songName) {
			this.songName = songName;
		}

		public String getArtist() {
			return artist;
		}

		public void setArtist(String artist) {
			this.artist = artist;
		}

		public String getDuration() {
			return duration;
		}

		public void setDuration(String duration) {
			this.duration = duration;
		}

		public String getGenre() {
			return genre;
		}

		public void setGenre(String genre) {
			this.genre = genre;
		}

		public Movie getMovie() {
			return movie;
		}

		public void setMovie(Movie movie) {
			this.movie = movie;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((artist == null) ? 0 : artist.hashCode());
			result = prime * result + ((duration == null) ? 0 : duration.hashCode());
			result = prime * result + ((genre == null) ? 0 : genre.hashCode());
			result = prime * result + ((movie == null) ? 0 : movie.hashCode());
			result = prime * result + songId;
			result = prime * result + ((songName == null) ? 0 : songName.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Songs other = (Songs) obj;
			if (artist == null) {
				if (other.artist != null)
					return false;
			} else if (!artist.equals(other.artist))
				return false;
			if (duration == null) {
				if (other.duration != null)
					return false;
			} else if (!duration.equals(other.duration))
				return false;
			if (genre == null) {
				if (other.genre != null)
					return false;
			} else if (!genre.equals(other.genre))
				return false;
			if (movie == null) {
				if (other.movie != null)
					return false;
			} else if (!movie.equals(other.movie))
				return false;
			if (songId != other.songId)
				return false;
			if (songName == null) {
				if (other.songName != null)
					return false;
			} else if (!songName.equals(other.songName))
				return false;
			return true;
		}


		@Override
		public String toString() {
			return "Songs [songId=" + songId + ", songName=" + songName + ", artist=" + artist + ", duration="
					+ duration + ", genre=" + genre + ", movie=" + movie + "]";
		}

		
		
}
