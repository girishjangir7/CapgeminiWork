package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;

import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;


public interface BankingServices {
	
	
	float depositAmount(long accountNo, float amount)throws AccountNotFoundException,
	BankingServicesDownException,AccountBlockedException;
	
	Account getAccountDetails(long accountNo)throws AccountNotFoundException,BankingServicesDownException;
	
	List<Account> getAllAccountDetails()throws BankingServicesDownException;

	
	public String accountStatus(long accountNo)throws BankingServicesDownException
	,AccountNotFoundException,AccountBlockedException;

	List<Transaction> getAccountAllTransactions(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException;

	boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, long pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException;

	float withdrawAmount(long accountNo, float amount, long pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException,InvalidAmountException;
	
	Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException;

	/* List<Transaction> getOneAccountAllTransactions(long accountNo); */

	
}
