package com.cg.banking.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {
	@Autowired
	BankingServices bankingServices;
	
	@RequestMapping("/registerCustomerAccount")
	public ModelAndView registerCustomerAccount(@ModelAttribute Account account) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		account = bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage", "account", account);
	}
	
	@RequestMapping("/accountDetails")
	public ModelAndView getAccountDetails(@RequestParam long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account = bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("getAccountDetailsPage", "account", account);
	}
	
	@RequestMapping("/depositAmountAction")
	public ModelAndView getDepositAmount(@RequestParam("accountNo") long accountNo, @RequestParam("depoAmount") float amount) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
				float balance = bankingServices.depositAmount(accountNo, amount);
				Account account =  bankingServices.getAccountDetails(accountNo);
				return new ModelAndView("getDepositAmountPage", "balance", account.getAccountBalance());
	}
	
	@RequestMapping("/withdrawAmountAction")
	public ModelAndView getWithdrawAmount(@RequestParam("accountNo") long accountNo, @RequestParam("withdrawAmount") float amount,@RequestParam("pinNumber") int pinNumber ) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException, InvalidAmountException {
				float balance = bankingServices.withdrawAmount(accountNo, amount, pinNumber);
				Account account =  bankingServices.getAccountDetails(accountNo);
				return new ModelAndView("getWithdrawAmountPage", "balance", account.getAccountBalance());
	}
	
	@RequestMapping("/getAllAccountDetails")
	public ModelAndView getAllAccountDetails() throws BankingServicesDownException {
		List<Account> account = bankingServices.getAllAccountDetails();
		return new ModelAndView("getAllAccountDetailsPage", "account", account);
	}
	
	@RequestMapping("/fundTransferAction") 
	public ModelAndView getfundTransfer(@RequestParam("recieverAccountNumber") long accountNoTo, @RequestParam("senderAccountNumber")long accountNoFrom,@RequestParam("amount") float transferAmount,@RequestParam("pinNumber") int pinNumber ) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException, InvalidAmountException {
				boolean amountTransferStatus = bankingServices.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
				boolean transfer = true;
				return new ModelAndView("getFundTransferPage", "transfer", transfer);
	}
	@RequestMapping("/accountAllTransactionsAction")
	public ModelAndView getAccountAllTransactions(@RequestParam("accountNo") long accountNo) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		List<Transaction> transactions = bankingServices.getAccountAllTransactions(accountNo);
		return new ModelAndView("getAccountAllTransactionsSuccessPage", "transactions", transactions);
	}
}
