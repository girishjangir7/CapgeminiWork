package com.cg.banking.services;

import java.util.HashMap;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;


@Component("bankingServices")
public class BankingServicesImpl implements BankingServices{
	Account account;
	
	@Autowired
	private AccountDAO accountDao;
	@Autowired
	TransactionDAO transaction;
	
	int minBalance=500;
	int PIN_NUMBER_COUNTER=4598;
	public int pinNumber() {
		return ++PIN_NUMBER_COUNTER;
	}
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException,
			InvalidAccountTypeException,BankingServicesDownException {
		if(!(account.getAccountType().equalsIgnoreCase("Savings") | account.getAccountType().equalsIgnoreCase("Current")))
			throw new InvalidAccountTypeException("Invalid Account Type");
		if(account.getAccountBalance()<0 || account.getAccountBalance()<500 )
			throw new InvalidAmountException("Invalid Amount!!! Enter Amount < 500");
		account.setAccountStatus("Active");
		account.setPinNumber(pinNumber());
		account.transactions = new HashMap<Integer, Transaction>();
		accountDao.save(account);
		return account;
	}
	
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=new Account();
		account=accountDao.findById(accountNo).orElseThrow
				 (()->new AccountNotFoundException("Requested Account not found"));
			account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction tran= new Transaction(amount,"Deposit");
		tran.setAccount(account);
		transaction.save(tran);
		accountDao.save(account);
		return account.getAccountBalance();	
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, long pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account=new Account();
		 account=accountDao.findById( accountNo).orElseThrow
				 (()->new AccountNotFoundException("Account Number Does Not Exist"));
		if(pinNumber==account.getPinNumber()){
			account.setAccountBalance(account.getAccountBalance()-amount);
			Transaction tran= new Transaction(amount,"Withdraw");
			tran.setAccount(account);
			transaction.save(tran);
			accountDao.save(account);
			return account.getAccountBalance();
		}
		else
			throw new InvalidPinNumberException("Invalid Pin Number entered!!!");
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accountDao.findById(accountNo).orElseThrow
				 (()->new AccountNotFoundException("Requested Account not found"));
		
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDao.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransactions(long accountNo) throws BankingServicesDownException, AccountNotFoundException {
		return transaction.findAll();
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account=accountDao.findById( accountNo).orElseThrow
				 (()->new AccountNotFoundException("Requested Account not found"));
		return account.getAccountStatus();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, long pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo=getAccountDetails(accountNoTo);
		Account customerFrom=getAccountDetails(accountNoFrom);

		if(customerFrom.getAccountBalance()-transferAmount<=minBalance)
			throw new InsufficientAmountException("Your Account Balance is Too Low");
		else if(customerFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException("Pin Number Does not match");
		else
		withdrawAmount(accountNoFrom, transferAmount, pinNumber);
		depositAmount(customerTo.getAccountNo(), transferAmount);
		return true;
	}


	
	/*
	 * @Override public List<Transaction> getOneAccountAllTransactions(long
	 * accountNo) {
	 * 
	 * return transaction.findAllTransactions(accountNo); }
	 */
	 
}
