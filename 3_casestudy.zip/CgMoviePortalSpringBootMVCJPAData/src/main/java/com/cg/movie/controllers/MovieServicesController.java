package com.cg.movie.controllers;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Songs;
import com.cg.movie.exceptions.MovieDetailNotFoundException;
import com.cg.movie.exceptions.SongsDetailNotFoundException;
import com.cg.movie.services.MovieServices;

@RestController
public class MovieServicesController {

	@Autowired
	MovieServices movieServices;
	
	@RequestMapping(value={"/sayHello"},method=RequestMethod.GET)
	public ResponseEntity<String> sayHello(){
		return new ResponseEntity<String>("Hello World to REST Services", HttpStatus.OK);
	}
	
	//Method-1
	@RequestMapping(value={"/getMovieDetails"},method=RequestMethod.GET, 
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Movie> getMovieDetailsRequestParam(@RequestParam int movieId) throws MovieDetailNotFoundException{
		Movie movie = movieServices.getMovieDetails(movieId);
		return new ResponseEntity<Movie>(movie, HttpStatus.OK);
	}
	
	//Method-2
	@RequestMapping(value={"/getMovieDetails/{associateId}"},method=RequestMethod.GET, 
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Movie> getMovieDetailsPathParam(@PathVariable(value="movieId") int movieId) throws MovieDetailNotFoundException{
		Movie movie = movieServices.getMovieDetails(movieId);
		return new ResponseEntity<Movie>(movie, HttpStatus.OK);
	}
	
	@RequestMapping(value={"/getAllMovieDetails"},method=RequestMethod.GET, 
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<List<Movie>> getAllMovieDetailsPathParam() {
		return new ResponseEntity<List<Movie>>(movieServices.getAllMovieDetails(), HttpStatus.OK);
	}
	
	@RequestMapping(value={"/acceptMovieDetails"},method=RequestMethod.POST, 
			produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE, headers="Accept=application/json")
	public ResponseEntity <String> acceptMovieDetails(@ModelAttribute Movie movie) {
		movie= movieServices.acceptMovieDetails(movie);
		return new ResponseEntity <String>("Movie details successfully added and movieId:- "+movie.getMovieId(), HttpStatus.OK);
	}
	
	@RequestMapping(value={"/removeMovieDetails"},method=RequestMethod.DELETE, 
			produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE, headers="Accept=application/json")
	public @ResponseBody ResponseEntity <String> removeMovieDetails(@RequestParam int movieId) throws MovieDetailNotFoundException {
		movieServices.removeMovieDetails(movieId);
		return new ResponseEntity <String>("Movie details successfully removed!!! ", HttpStatus.OK);
	}
	
	@RequestMapping(value={"/acceptSongsDetails"},method=RequestMethod.POST, 
			produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE, headers="Accept=application/json")
	public ResponseEntity <String> acceptSongDetails(@RequestParam int movieId ,@ModelAttribute Songs songs) throws MovieDetailNotFoundException {
		songs= movieServices.acceptSongsDetails(songs, movieId);
		return new ResponseEntity <String>("Songs details successfully added and movieId:- "+songs.getSongId(), HttpStatus.OK);
	}
	
	@RequestMapping(value={"/getSongsDetails"},method=RequestMethod.GET, 
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Songs> getSongsDetailsRequestParam(@RequestParam int songId) throws MovieDetailNotFoundException, SongsDetailNotFoundException{
		Songs song = movieServices.getSongsDetail(songId);
		return new ResponseEntity<Songs>(song, HttpStatus.OK);
	}
	
	@RequestMapping(value={"/removeSongsDetails"},method=RequestMethod.DELETE, 
			produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE, headers="Accept=application/json")
	public @ResponseBody ResponseEntity <String> removeSongsDetails(@RequestParam int songId) throws MovieDetailNotFoundException, SongsDetailNotFoundException {
		movieServices.removeSongsDetails(songId);
		return new ResponseEntity <String>("Song details successfully removed!!! ", HttpStatus.OK);
	}
	
	@RequestMapping(value={"/getAllSongsDetails"},method=RequestMethod.GET, 
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<List<Songs>> getAllSongsDetailsPathParam() {
		return new ResponseEntity<List<Songs>>(movieServices.getAllSongsDetails(), HttpStatus.OK);
	}
}
	   

