package com.capgemini.salesmanagement.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;


public class Client {

	public static void main(String[] args) {
		ISaleService services = new SaleService();
		Scanner sc = new Scanner(System.in); 
		int index = 0;
		System.out.println("-----------------------:Welcome to the SaleManagementSystem:-------------------------");
		for(int i=0;i<2;i++) {
			System.out.println("Choose among the given options: ");
			index =sc.nextInt();

			switch(index) {

			case 1:
				try {
					SaleService saleService=new SaleService();
					System.out.println(saleService.insertSalesDetails(1002,"TV","Electronics",220));
				
				}
					catch(Exception e) {
						e.printStackTrace();
						break;
						}
			case 2: System.exit(0);
				default:
					System.out.println("Invalid Option,Please Try Again!!!!!"); }
				System.out.println("---------------------------------------------------------------------------------------"); 
				System.out.println("Do you want to continue?");
				System.out.println("1.Yes"); 
				System.out.println("2.No"); 
				int count =sc.nextInt();
				if(count==2) { 
					System.exit(0);
				}
				else { 
					main(null);
				}

			}

		}

	}
