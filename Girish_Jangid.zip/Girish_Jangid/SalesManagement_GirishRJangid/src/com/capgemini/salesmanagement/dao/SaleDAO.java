package com.capgemini.salesmanagement.dao;

import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {

	@Override
	public Sale insertSalesDetails(Sale sale) {
		sale.setSaleId(CollectionUtil.getSALEID());
		sale.setSaleDate(LocalDate.now());
		Sale sale1 = CollectionUtil.sales.put(sale.getSaleId(),sale);
		return sale1;
	}

}
