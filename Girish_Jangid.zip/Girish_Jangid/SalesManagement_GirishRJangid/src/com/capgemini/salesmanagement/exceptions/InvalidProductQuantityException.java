package com.capgemini.salesmanagement.exceptions;

public class InvalidProductQuantityException extends Exception {

}
