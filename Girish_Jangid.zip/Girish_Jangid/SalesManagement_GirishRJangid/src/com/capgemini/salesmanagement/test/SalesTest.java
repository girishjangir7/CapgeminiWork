package com.capgemini.salesmanagement.test;

import org.junit.BeforeClass;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.service.ISaleService;

public class SalesTest {
	private static ISaleService services;
	
	@BeforeClass
	public static void setUpTestEnv() {
		
	}
}
