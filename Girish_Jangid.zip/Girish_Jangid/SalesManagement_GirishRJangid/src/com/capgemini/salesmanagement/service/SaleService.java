package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidProductQuantityException;
import com.capgemini.salesmanagement.util.CollectionUtil;


public class SaleService implements ISaleService
{
	private ISaleDAO saleDao=new SaleDAO();

	@Override
	public boolean validateProductCode(int productId) throws InvalidProductCodeException  {
		if(productId==1001||productId==1002||productId==1003||productId==1004)
			return true;
		throw new InvalidProductCodeException();
	}

	@Override
	public boolean validateQuantity(int qty) throws InvalidProductQuantityException {
		if(qty>0 && qty <5)
			return true;
		throw new InvalidProductQuantityException();
		
	}

	@Override
	public boolean validateProductCat(String prodCat) throws InvalidProductCategoryException {
		if(prodCat=="Electronics"|| prodCat == "Toys")
			return true;
		throw new InvalidProductCategoryException();
		
	}

	@Override
	public boolean validateProductName(String prodName) throws InvalidProductNameException {
		if(!(prodName==null))
			throw new InvalidProductNameException();
		return true;
	
	}

	@Override
	public boolean validateProductPrice(float price) throws InvalidProductPriceException {
		if(price>200)
			return true;
		throw new InvalidProductPriceException();
	}

	@Override
	public Sale insertSalesDetails(int prodCode, String productName, String category,
			float prodPrice) throws InvalidProductCodeException, InvalidProductNameException, InvalidProductCategoryException, InvalidProductPriceException {
		Sale sale=new Sale(prodCode,productName,category,prodPrice);
		if (validateProductCode(prodCode)==true || validateProductName(productName)==true || validateProductCat(category)==true || validateProductPrice(prodPrice)==true)
		sale=saleDao.insertSalesDetails(sale);
		return sale;
	}
	
}
