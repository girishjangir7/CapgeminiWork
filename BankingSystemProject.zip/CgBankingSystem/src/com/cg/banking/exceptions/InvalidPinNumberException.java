package com.cg.banking.exceptions;

public class InvalidPinNumberException extends Exception {
	public InvalidPinNumberException() {
		System.out.println("The enterd pin is invalid!!!");
	}
}
