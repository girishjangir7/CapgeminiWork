package com.cg.banking.exceptions;

public class InsufficientAmountException extends Exception{
	public InsufficientAmountException() {
		System.out.println("This Account does not have sufficient amount!!!");
	}
}
