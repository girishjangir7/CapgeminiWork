package com.cg.banking.exceptions;

public class InvalidAmountException extends Exception {
	public InvalidAmountException() {
		System.out.println("Specififed Amount is invalid!!!");
	}
}
