package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utils.BankingDBUtil;

public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		Scanner sc  = new Scanner(System.in);
		int index = 0;
		String accountType;
		long initialBalance;
		long accountNumber = 0;
		System.out.println("-----------------------:Welcome to the MImpulse Bank:-------------------------");
		BankingServices bankServices = new BankingServicesImpl();

		for(int i=0;i<2;i++) {
			System.out.println("Choose among the given options: ");
			System.out.println("1.Create Account: ");
			System.out.println("2.Get Account Detail:");
			System.out.println("3.Get All Account Details: ");
			System.out.println("4.Deposit Amount:");
			System.out.println("5.Withdraw Amount:");
			System.out.println("6.Get all transactions of the account:");
			System.out.println("7.Funds Transfer:");
			System.out.println("Enter the function you want to perform: ");
			index = sc.nextInt();

			switch(index) {
			case 1: 
				System.out.println("Enter the type of account you want to open:");
				System.out.println("Choose one: Savings or Current");
				accountType=sc.next();
				System.out.println("Enter your account Balance:");
				initialBalance=sc.nextLong();
				Account account = bankServices.openAccount(accountType,initialBalance);
				System.out.println(account);
				System.out.println("Your account has been created:-");

				break;
			case 2:
				System.out.println("Enter the account number:");
				accountNumber=sc.nextLong();
				try {

					System.out.println(bankServices.getAccountDetails(accountNumber));
				}
				catch(AccountNotFoundException e) {
					e.printStackTrace();
				}

				break;
			case 3 : 
				try {

					System.out.println(bankServices.getAllAccountDetails());

				}
				catch(BankingServicesDownException e) {
					e.printStackTrace();
				}
				break;
			case 4: 
				try {

					System.out.println("Enter the account number in which you want to deposit: ");
					long depositAccNo = sc.nextLong();		


					System.out.println("Enter the deposit amount:");
					float depoAmount = sc.nextFloat();


					sc.nextLine();
					System.out.println("After deposit finalAmount: "+bankServices.depositAmount(accountNumber, depoAmount));
				}catch(AccountNotFoundException e) {
					e.printStackTrace();
				}
				break;
			case 5: 
				try{
					System.out.println("Enter the accountNo from which you want to withdraw:"); 
					long withdrawAccount =sc.nextLong();		


					System.out.println("Enter the amount that you want to withdraw:");
					float withdrawAmount =sc.nextFloat();
					System.out.println("Enter the pin number of the account from which you want to withraw:");
					int withdrawPinNumber =sc.nextInt();
					sc.nextLine();
					System.out.println("After withdrawal finalAmount: "+bankServices.withdrawAmount(withdrawAccount, withdrawAmount,withdrawPinNumber ));

				}

				catch(AccountNotFoundException e) {
					e.printStackTrace();
				}
				catch(InvalidPinNumberException e) {
				}


				break;
			case 6: System.out.println("Enter the accountNo for which you want to show transactions:");
			long accountNo =sc.nextLong();
			sc.nextLine();
			System.out.println("Transactions are :");
			System.out.println(bankServices.getAllAccountTransaction(accountNo));
			break;
			case 7: System.out.println("Enter the accountNo from which you want to transfer funds:");
			long senderAccount =sc.nextLong();
			sc.nextLine();
			System.out.println("Enter the amount that you want to transfer:");
			float transferAmount =sc.nextFloat();
			sc.nextLine();
			System.out.println("Enter the pin number of the account from which you want to transfer:");
			int transferPinNumber =sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the accountNo of the receiver:");
			long receiverAccount =sc.nextLong();
			sc.nextLine();
			System.out.println("After funds transfer finalAmount: "+bankServices.fundTransfer(receiverAccount, senderAccount, transferAmount, transferPinNumber) );
			break;
			default: 
				System.out.println("Invalid Option,Please Try Again!!!!!");
			}
		}
		System.out.println("---------------------------------------------------------------------------------------");
		System.out.println("Do you want to continue?");
		System.out.println("1.Yes");
		System.out.println("2.No");
		int count = sc.nextInt();
		if(count==2) 
			System.exit(0);
		else 
			main(null);

	}


}
