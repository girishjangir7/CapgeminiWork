package com.cg.banking.exceptions;

public class BankingServicesDownException extends Exception{
	public BankingServicesDownException(String str) {
		super(str);
	}
}
