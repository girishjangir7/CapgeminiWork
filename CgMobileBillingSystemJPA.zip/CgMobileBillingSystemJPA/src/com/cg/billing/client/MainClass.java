package com.cg.billing.client;

import java.util.Scanner;

import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PlanDAOImpl;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

public class MainClass {
	static  Scanner sc= new Scanner(System.in);
	static BillingServices services=new BillingServicesImpl();
	public static void main(String args[]) throws BillDetailsNotFoundException ,CustomerDetailsNotFoundException,InvalidBillMonthException,PlanDetailsNotFoundException,PostpaidAccountNotFoundException  {
	mainScreen();
	int userChoice=sc.nextInt();
	startMenu(userChoice);
	}
	public static void startMenu(int userChoice) throws BillDetailsNotFoundException ,CustomerDetailsNotFoundException,InvalidBillMonthException,PlanDetailsNotFoundException,PostpaidAccountNotFoundException {

		switch(userChoice) {
		
		case 1: 
			            System.out.println("Please Fill Details To Add New Customer.");
			            System.out.println("Enter First Name.");
						String firstName=sc.next();
						System.out.println("Enter Last Name.");
						String lastName = sc.next();
						System.out.println("Enter EmailId");
						String emailID=sc.next();
						System.out.println("Enter DOB");
						String dateOfBirth=sc.next();
						System.out.println("Enter Billing Address city");
						String billingAddressCity=sc.next();
						System.out.println("Enter Billing Address state");
						String billingAddressState=sc.next();
						System.out.println("Enter Billing Address pin code");
						int billingAddressPinCode=sc.nextInt();
						System.out.println("Enter Home Address city");
						String homeAddressCity=sc.next();
						System.out.println("Enter Home Adress state");
						String homeAddressState=sc.next();
						System.out.println("Enter Home Adress pin code");
						int homeAddressPinCode = sc.nextInt();
						int customerId = services.acceptCustomerDetails(firstName, lastName, emailID, dateOfBirth, billingAddressCity, billingAddressState, billingAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
						System.out.println("******ACCOUNT CREATED******");
						System.out.println(customerId);
						break;
		                						
		case 2:   try {
			            System.out.println("Enter Customer Id");
                        int customerID=sc.nextInt();
						System.out.println("Enter Plan Id");
					    int planID= sc.nextInt();
						System.out.println(services.openPostpaidMobileAccount(customerID, planID));
						break;
						}catch(CustomerDetailsNotFoundException e) {e.printStackTrace();}
                    	  catch(PlanDetailsNotFoundException e) {e.printStackTrace();}
		
		case 3:   services.createPlanDetails();
		        		break;
		                 
		
		case 4:  try {
	                   System.out.println("Enter Customer Id");
                       int customerID=sc.nextInt();
				       System.out.println("Enter Plan Id");
			           int planID= sc.nextInt();
			           System.out.println("Enter Mobile Number");
			           long mobileNo=sc.nextLong();
				       System.out.println(services.changePlan(customerID, mobileNo, planID));
				       break;
				       }catch(CustomerDetailsNotFoundException e) {e.printStackTrace();}
            	         catch(PlanDetailsNotFoundException e) {e.printStackTrace();}
		                 catch(PostpaidAccountNotFoundException e) {e.printStackTrace();}
		              
		case 5:   System.out.println(services.getAllCustomerDetails());
		                break;
		                
		case 6:   try {
			            System.out.println("Enter Customer Id");
                        int customerID=sc.nextInt();
	                    System.out.println("Enter Mobile Number");
	                    long mobileNo=sc.nextLong();
			            System.out.println(services.getPostPaidAccountDetails(customerID, mobileNo));
			            break;
		                 }catch(CustomerDetailsNotFoundException e) {e.printStackTrace();}
		                   catch(PostpaidAccountNotFoundException e) {e.printStackTrace();}
		
		case 7: System.out.println(services.getAllCustomerDetails());
		              break;
		
		case 8:
			try {
		           	System.out.println("Enter plan Id:");
                    int planID=sc.nextInt();
                    System.out.println(services.getPlanDetails(planID));
                            }catch (PlanDetailsNotFoundException e) {e.printStackTrace();}
	              	 break;
		case 9:try {
			        System.out.println("Enter Customer Id:");
                    int customerID=sc.nextInt();
                    System.out.println("Enter Mobile no:");
                    long mobileNo=sc.nextLong();
                    System.out.println(services.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo));
		                    }catch(CustomerDetailsNotFoundException e) {e.printStackTrace();}
                             catch(PostpaidAccountNotFoundException e) {e.printStackTrace();}
		             break;
		case 10:try {
			         System.out.println("Enter Customer Id:");
                     int customerID=sc.nextInt();
                     System.out.println("Enter Mobile no:");
                     long mobileNo=sc.nextLong();
                     System.out.println("Enter String Month");
                     String billMonth = sc.next();
                     System.out.println(services.getMobileBillDetails(customerID, mobileNo, billMonth));
	                      }catch(CustomerDetailsNotFoundException e) {e.printStackTrace();}
                            catch(PostpaidAccountNotFoundException e) {e.printStackTrace();}
		             break;
		case 11:try {
			         System.out.println("Enter Customer Id:");
                     int customerID=sc.nextInt();
                     System.out.println(services.removeCustomerDetails(customerID));
		                     }catch(CustomerDetailsNotFoundException e) {e.printStackTrace();}
	                break;
		case 12:try {
			          System.out.println("Enter Customer Id:");
                      int customerID=sc.nextInt();
                      System.out.println("Enter Mobile no:");
                      long mobileNo=sc.nextLong();
                      System.out.println("Enter String Month");
                      String billMonth = sc.next();
                      System.out.println("Enter Number of local SMS");
		              int noOfLocalSMS=sc.nextInt();
		              System.out.println("Enter Number of STD SMS");
		              int noOfStdSMS=sc.nextInt();
		              System.out.println("Enter Number of local calls");
		              int noOfLocalCalls=sc.nextInt();
		              System.out.println("Enter Number of STD calls");
		              int noOfStdCalls=sc.nextInt();
		              System.out.println("Enter Number of Internet Data Usage");
		              int internetDataUsageUnits=sc.nextInt();
		              System.out.println(services.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits));
		                     }catch(CustomerDetailsNotFoundException e) {e.printStackTrace();}
                               catch(PostpaidAccountNotFoundException e) {e.printStackTrace();}
		             break;
		case 13:try {
                      System.out.println("Enter Customer Id");
                      int customerID=sc.nextInt();
                      System.out.println("Enter Mobile Number");
                      long mobileNo=sc.nextLong();
                      System.out.println(services.getPostPaidAccountDetails(customerID, mobileNo));
             }catch(CustomerDetailsNotFoundException e) {e.printStackTrace();}
               catch(PostpaidAccountNotFoundException e) {e.printStackTrace();}
		             break;
		default:System.out.println("Invalid Choice,Please Try Again!!!!!!");
		}
		System.out.println("What do you want to do now ?");
		System.out.println("1. Continue");
		System.out.println("2. Exit");
		int choice =sc.nextInt();
		if(choice==2)
			System.exit(0);
		main(null);
	}
	public static void mainScreen(){
		System.out.println("-----------------------------:Welcome to Mobile Billing System:-----------------------------");
		System.out.println("Please enter any one of the given choices :");
		System.out.println("1. Add new customer");
		System.out.println("2. Open New PostPaid Account");
		System.out.println("3. Create New Plan ");
		System.out.println("4. Change Plan");
		System.out.println("5. Show All Customers");
		System.out.println("6. Show Postpaid Account Details:");
		System.out.println("7. Show All Plan Details:");
		System.out.println("8. Show particular Plan Details");
		System.out.println("9. Show all bills of a customer");
		System.out.println("10.Show Particular month bill");
		System.out.println("11.Remove Customer Details");
		System.out.println("12.Generate bill");
		System.out.println("13.Close Postpaid Account. ");
	}
}
