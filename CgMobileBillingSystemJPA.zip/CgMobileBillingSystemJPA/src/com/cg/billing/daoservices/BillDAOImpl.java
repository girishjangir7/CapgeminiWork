package com.cg.billing.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.billing.beans.Bill;

public class BillDAOImpl implements BillDAO{
	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Bill save(Bill bill) {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(bill);
		entityManager.getTransaction().commit();
		entityManager.close();
		return bill;
	}

	@Override
	public boolean update(Bill bill) {
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(bill);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Bill findOne(long billId) {
		
		return entityManagerFactory.createEntityManager().find(Bill.class, billId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Bill> findAll() {
		
		Query query = entityManagerFactory.createEntityManager().createQuery("from Bill b");
		return query.getResultList();
	}

	@Override
	public Bill retrieveBillDetails(long mobileNo, String billMonth) {
		return (Bill) entityManagerFactory.createEntityManager().createQuery("from Bill b where b.postpaidAccount="+mobileNo+" and billMonth='"+billMonth+"'").getSingleResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Bill> retrieveAllBillDetailsForAccount(long mobileNo) {
		return (List<Bill>) entityManagerFactory.createEntityManager().createQuery("from Bill b where b.postpaidAccount="+mobileNo).getResultList();
		
	}

}
