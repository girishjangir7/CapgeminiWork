package com.cg.billing.daoservices;
import java.util.List;
import com.cg.billing.beans.Plan;

public interface PlanDAO
{
    boolean update(Plan plan);
    Plan findOne(int planId);
    List<Plan> findAll();
	Plan save(Plan plan);
	
}
