package com.cg.billing.services;

import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.cg.billing.beans.Address;
import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.BillDAO;
import com.cg.billing.daoservices.BillDAOImpl;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.CustomerDAOImpl;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PlanDAOImpl;
import com.cg.billing.daoservices.PostpaidAccountDAO;
import com.cg.billing.daoservices.PostpaidAccountDAOImpl;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

public class BillingServicesImpl implements BillingServices
{
    private CustomerDAO customerDAO = new CustomerDAOImpl();
    private PlanDAO planDAO = new PlanDAOImpl();
    private PostpaidAccountDAO postpaidAccountDAO = new PostpaidAccountDAOImpl();
    private BillDAO billDAO = new BillDAOImpl();
    
	@Override
	public List<Plan> getPlanAllDetails() 
	{
		return planDAO.findAll();
		 
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
		List<Address> address = new ArrayList<Address>();
		Address homeAddress = new Address(homeAddressCity,
				homeAddressState,homeAddressPinCode);
		Address billingAddress = new Address(billingAddressCity,billingAddressState,billingAddressPinCode);
		address.add(homeAddress);
		address.add(billingAddress);
		Customer customer = new Customer(firstName, lastName, emailId, dateOfBirth,address);
		customerDAO.save(customer);
		return customer.getCustomerId();
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		Customer customer = customerDAO.findOne(customerID);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    Plan plan =planDAO.findOne(planID);
	    if(plan==null)
	    	throw new PlanDetailsNotFoundException("No plan details found!");
		PostpaidAccount postpaidAccount = new PostpaidAccount(plan,null,customer);
		postpaidAccount = postpaidAccountDAO.save(postpaidAccount);
		long mobileNo = postpaidAccount.getMobileNo();
		Map<Long, PostpaidAccount> accounts = new HashMap<>();
		accounts.put(mobileNo,postpaidAccount);
		customer.setPostpaidAccount(accounts);
		return mobileNo;
	}

	@Override
	public double generateMonthlyMobileBill(int customerId, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, PlanDetailsNotFoundException {
		Customer customer = customerDAO.findOne(customerId);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findOne(mobileNo);
	    if(postpaidAccount==null)
	    	throw new PostpaidAccountNotFoundException("Sorry, Invalid Mobile Number!");
	    Plan plan = postpaidAccount.getPlan();
		if (plan == null)
			throw new PlanDetailsNotFoundException("No Plan Details Found!");
	    int flag=0;
		for (Enum month : Month.values()) {
			if (month.toString().equalsIgnoreCase(billMonth)) {
				flag=1;
				break;
			}
		}
		if (flag==0)	
			throw new InvalidBillMonthException("Please enter a Valid Month");
		int a;
		float localSMSAmount = (a = (noOfLocalSMS - plan.getFreeLocalSMS())) <= 0 ? 0 : a * plan.getLocaSMSRate();
		float localCallAmount = (a = (noOfLocalCalls - plan.getFreeLocalCalls())) <= 0 ? 0 : a * plan.getLocalCallRate();
		float stdSMSAmount = (a = (noOfStdSMS - plan.getFreeStdSMS())) <= 0 ? 0 : a * plan.getLocalCallRate();
		float stdCallAmount = (a = (noOfStdCalls - plan.getFreeStdCalls())) <= 0 ? 0 : a * plan.getStdCallRate();
		float internetDataUsageAmount = (a = (internetDataUsageUnits - plan.getFreeInternetUsageUnits())) <= 0 ? 0 : a * plan.getInternetDataUsageRate();
		float totalAmountWithoutTaxes = localCallAmount + localSMSAmount + stdCallAmount + stdSMSAmount + internetDataUsageAmount + plan.getMonthlyRental();
		float cgst = 0.09f * totalAmountWithoutTaxes;
		float sgst = 0.09f * totalAmountWithoutTaxes;
		float stateGST = cgst + sgst;
		float centralGST = 0.05f * totalAmountWithoutTaxes;
		float totalBillAmount = totalAmountWithoutTaxes + centralGST + stateGST;
		Bill bill = new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, stateGST, centralGST, postpaidAccount);
		bill = billDAO.save(bill);
		return bill.getBillId();
}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFoundException {
		if(customerDAO.findOne(customerId)==null)
			throw new CustomerDetailsNotFoundException("Given customer details not found!!!");
		return customerDAO.findOne(customerId);
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		
		return customerDAO.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = customerDAO.findOne(customerID);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findOne(mobileNo);
	    if(postpaidAccount==null)
	    	throw new PostpaidAccountNotFoundException("Sorry, Invalid Postpaid Account Details!");
		return postpaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {
	
		return postpaidAccountDAO.findAll();
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
		Customer customer = customerDAO.findOne(customerID);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findOne(mobileNo);
	    if(postpaidAccount==null)
	    	throw new PostpaidAccountNotFoundException("Sorry, Invalid Postpaid Account Details!");
	Bill bill = billDAO.retrieveBillDetails(mobileNo, billMonth);
		return bill;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = customerDAO.findOne(customerID);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findOne(mobileNo);
	    if(postpaidAccount==null)
	    	throw new PostpaidAccountNotFoundException("Sorry, Invalid Postpaid Account Details!");
		List<Bill> bills=billDAO.retrieveAllBillDetailsForAccount(mobileNo);
		return bills;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		Customer customer = customerDAO.findOne(customerID);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findOne(mobileNo);
	    if(postpaidAccount==null)
	    	throw new PostpaidAccountNotFoundException("Sorry, Invalid Postpaid Account Details!");
	    Plan plan =postpaidAccount.getPlan();
	    if(plan==null)
	    	throw new PlanDetailsNotFoundException("No plan details found!");
		postpaidAccount.setPlan(plan);
		postpaidAccountDAO.save(postpaidAccount);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = customerDAO.findOne(customerID);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findOne(mobileNo);
	    if(postpaidAccount==null)
	    	throw new PostpaidAccountNotFoundException("Sorry, Invalid Postpaid Account Details!");
	    postpaidAccountDAO.deleteCustomerAccount(mobileNo);
		return true;
		
	
	}

	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		Customer customer = customerDAO.findOne(customerID);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    customerDAO.removeCustomer(customerID);
		return true;
		
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		Customer customer = customerDAO.findOne(customerID);
	    if(customer==null)
	    	throw new CustomerDetailsNotFoundException("Sorry, Customer Not Found!");
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findOne(mobileNo);
	    if(postpaidAccount==null)
	    	throw new PostpaidAccountNotFoundException("Sorry, Invalid Postpaid Account Details!");
	    Plan plan = postpaidAccount.getPlan();
	    if(plan==null)
	    	throw new PlanDetailsNotFoundException("Plan details not found!");
		return plan;
		
	}
	@Override
	public void createPlanDetails( )
	{
		
		planDAO.save(new Plan(502,200,300,100,4000,2000,3,0.5f,2.0f,1.0f,1.5f,40.0f,"Phase3","200Rs"));
		planDAO.save(new Plan(503,300,400,100,3000,1000,2,1.5f,2.0f,1.0f,2.5f,50.0f,"Goregaon","800Rs"));
		planDAO.save(new Plan(504,400,500,100,4000,2000,3,0.5f,1.0f,1.5f,1.5f,30.0f,"Mumbai","500Rs"));
		
	}

	@Override
	public Plan getPlanDetails(int planID) throws PlanDetailsNotFoundException {
		Plan plan = planDAO.findOne(planID);
		return plan;
	}

}
