package com.cg.banking.exceptions;

public class BankingServicesDownException extends Exception{
	public BankingServicesDownException() {
		System.out.println("Banking Services down for this account!!!");
	}
}
