package com.cg.banking.exceptions;

public class InvalidAccountTypeException extends Exception{
	public InvalidAccountTypeException() {
		System.out.println("Invalid Account Type!!!");
	}
}
