package com.cg.banking.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.utils.BankingDBUtil;


public class BankingServicesImpl implements BankingServices {
	  
		private AccountDAO accountDAO = new AccountDAOImpl() ;

		@Override
		public Account openAccount(String accountType, float initBalance)
				throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
				Account account = new Account(accountType, initBalance);
				account.transactions = new HashMap<>();
				accountDAO.save(account);
			return account;
		}

		@Override
		public float depositAmount(long accountNo, float amount)
				throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.findOne(accountNo);
			float finalAmount = account.getAccountBalance() + amount;
			account.setAccountBalance(finalAmount);
			
			Transaction transaction = new Transaction();
			Integer transactionId = BankingDBUtil.getTRANSACTION_ID_COUNTER();
			transaction.setTransactionId(transactionId);
			transaction.setAmount(amount);
			transaction.setTransactionType(BankingDBUtil.getTRANSACTION_DEPOSIT());
			account.transactions.put(transactionId,transaction);
		return finalAmount;
		}

		@Override
		public float withdrawAmount(long accountNo, float amount, int pinNumber)
				throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
				BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.findOne(accountNo);
			float finalBalance;
			if(pinNumber==account.getPinNumber()) {
				 	finalBalance = account.getAccountBalance()-amount;
				 	account.setAccountBalance(finalBalance);
				 	
				 	Transaction transaction = new Transaction();
				 	transaction.setTransactionType(BankingDBUtil.getTRANSACTION_WITHDRAW());
				 	Integer transactionId = BankingDBUtil.getTRANSACTION_ID_COUNTER();
				 	transaction.setTransactionId(transactionId);
				 	transaction.setAmount(amount);
				 	account.transactions.put(transactionId,transaction);
				 		return finalBalance;
			}
			else {
				throw new InvalidPinNumberException();
			}
		}

		@Override
		public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
				throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
				BankingServicesDownException, AccountBlockedException {
					withdrawAmount(accountNoFrom, transferAmount, pinNumber);
					depositAmount(accountNoTo, transferAmount);
				
					Transaction transaction = new Transaction();
					Account account = accountDAO.findOne(accountNoFrom);
					transaction.setTransactionType(BankingDBUtil.getTRANSACTION_FUNDTRANSFER());
					Integer transactionId=BankingDBUtil.getTRANSACTION_ID_COUNTER();
					transaction.setTransactionId(transactionId);
					transaction.setAmount(transferAmount);
					account.transactions.put(transactionId,transaction);
						return true;
		}

		@Override
		public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
			Account account = accountDAO.findOne(accountNo);
			if(account == null)
				throw new AccountNotFoundException();
			return account;
			
		}

		@Override
		public List<Account> getAllAccountDetails() throws BankingServicesDownException {
			return accountDAO.findAll();
		}

		@Override
		public List<Transaction> getAllAccountTransaction(long accountNo)
				throws BankingServicesDownException, AccountNotFoundException {
				Account account = accountDAO.findOne(accountNo);
				ArrayList<Transaction> listOfTransactions = new ArrayList<Transaction>(account.transactions.values());
				return listOfTransactions;
		}

		@Override
		public String accountStatus(long accountNo)
				throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
			Account account = accountDAO.findOne(accountNo);
			String status= account.accountStatus;
			return status;
		}
}