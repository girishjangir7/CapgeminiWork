package com.cg.banking.utils;

import java.util.HashMap;
import java.util.Random;

import com.cg.banking.beans.Account;

public class BankingDBUtil {
	
			static Random r = new Random();
			
			public static HashMap<Long, Account> customerAcc = new HashMap<Long, Account>();
			private static long accountNo = 45678901;
			public static String accountStatus = "Active";
			private static String transactionDebit = "Debit type";
			private static String transactionCredit = "Credit Type";
			private static String transactionForFundsTransfer = "Funds Transfer";
			private static Integer accountTransactionID = 100001;
			
			static private int num=9999-1000;
			public static int pinNumber = r.nextInt(9999)%num;
			
			
			public static Integer getTRANSACTION_ID_COUNTER() {
				return ++accountTransactionID;
			}
			public static long getACCOUNT_NO_COUNTER() {
				return ++accountNo;
			}
			
			public static int getPIN_NO_COUNTER() {
				return ++pinNumber;
			}
			public static String getTRANSACTION_FUNDTRANSFER() {
				return transactionForFundsTransfer;
			}
			public static String getTRANSACTION_DEBIT() {
				return transactionDebit;
			}
			
			public static String getTRANSACTION_CREDIT() {
				return transactionCredit;
			}
}
