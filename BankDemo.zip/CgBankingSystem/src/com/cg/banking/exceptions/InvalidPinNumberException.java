package com.cg.banking.exceptions;

public class InvalidPinNumberException extends Exception {
	public InvalidPinNumberException(String str) {
		super(str);
	}
}
