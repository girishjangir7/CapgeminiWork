package com.cg.payroll.controllers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

@WebServlet("/netSalary")
public class NetSalaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String FILE_NAME = "D:\\Salary.pdf";
	private static Document document = new Document();
	private PayrollServices services;
	@Override
	public void init() throws ServletException {
		services = new PayrollServicesImpl();
	}
	
	private static void generatePDF(Associate associate,HttpServletRequest request, HttpServletResponse response) {
		try {
			PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
			response.setContentType("application/pdf");      
			OutputStream out=response.getOutputStream();
				Document document = new Document();
				PdfWriter.getInstance(document, out);
				document.open();
				Paragraph p = new Paragraph();
			
				p.add("\n\n***************Salary details*****************");
				p.add("\nBasic Salary: " + associate.getSalary().getBasicSalary());
				p.add("\nHra: " + associate.getSalary().getHra());
				p.add("\nConveyence Allowance: " + associate.getSalary().getConveyenceAllowance());
				p.add("\nOther Allowance: " + associate.getSalary().getOtherAllowance());
				p.add("\nPersonalAllowance: " + associate.getSalary().getPersonalAllowance());
				p.add("\nMonthly Tax: " + associate.getSalary().getMonthlyTax());
				p.add("\nEpf: " + associate.getSalary().getEpf());
				p.add("\nCompany Pf: " + associate.getSalary().getCompanyPf());
				p.add("\nGross Salary: " + associate.getSalary().getGrossSalary());
				p.add("\nNet Salary: " + associate.getSalary().getNetSalary());
			
				document.add(p);
				document.close();
				out.close();
			}
			catch (FileNotFoundException | DocumentException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int associateId = Integer.parseInt(request.getParameter("associateId"));
		
		try {
			Associate associate=services.calculateNetSalary(associateId);
			generatePDF(associate, request, response);
			request.setAttribute("associate", associate);
			
			request.getRequestDispatcher("showNetSalary.jsp").forward(request, response);
			
		} catch (AssociateDetailNotFoundException e) {
			request.setAttribute("error", "Associate Id invalid!!!");
			request.getRequestDispatcher("netSalary.jsp").forward(request, response);
		}
		
	}
	
	@Override
	public void destroy() {
		services=null;
	}

}
