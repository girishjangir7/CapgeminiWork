package com.capgemini.xyz.service;


import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exceptions.InvalidCustomerNameException;
import com.capgemini.xyz.exceptions.InvalidEmailException;

public class LoanService implements ILoanService{
	private ILoanDao loanDao=new LoanDao();
	
	@Override
	public long applyLoan(Loan loan) {
		long loanId =loanDao.applyLoan(loan);
		return loan.getLoanID();
		
	}

	@Override
	public Customer validateCustomer(Customer customer) throws  InvalidEmailException, InvalidCustomerNameException {
		String name = customer.getCustName();
		String email = customer.getEmail();
	        if(name.matches("[A-Z]*[a-z]*" ))
	            	if(email.matches("^[a-zA-Z0-9_+&*-]+(?:\\."+ "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" +  "A-Z]{2,7}$"))
	            			return customer;
	            	else
	            		throw new InvalidEmailException("Email not valid");
	        else
	        	throw new InvalidCustomerNameException("Customer name not valid");
	}

	@Override
	public long insertCust(Customer cust) throws InvalidEmailException, InvalidCustomerNameException {
				validateCustomer(cust);
				return loanDao.insertCust(cust);
}

	@Override
	public double calculateEMI(double amount, int duration) {
		double emi = (amount*0.095*(1+0.095)*duration*12)/ (((1+0.095)*duration*12)-1);
		return emi;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		
		return loanDao.findAll();
	}

	@Override
	public List<Loan> getAllLoanDetails() {
	
		return loanDao.findAllLoan();
	}

}
