package com.capgemini.xyz.service;

import java.util.List;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exceptions.InvalidAmountException;
import com.capgemini.xyz.exceptions.InvalidCustomerNameException;
import com.capgemini.xyz.exceptions.InvalidDurationException;
import com.capgemini.xyz.exceptions.InvalidEmailException;


public interface ILoanService {
		public long applyLoan(Loan loan);
		public Customer validateCustomer(Customer customer) throws  InvalidEmailException, InvalidCustomerNameException;
		public long insertCust(Customer cust) throws  InvalidEmailException, InvalidCustomerNameException;
		public double calculateEMI(double amount, int duration) throws InvalidAmountException,InvalidDurationException;
		List <Customer> getAllCustomerDetails();
		List<Loan> getAllLoanDetails();
}
