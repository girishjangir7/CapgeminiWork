package com.capgemini.xyz.util;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class LoanDBUtil {
	public static Map<Integer,Customer> customerEntry = new HashMap<Integer,Customer>();
	public static Map<Integer,Loan> loanEntry= new HashMap<Integer,Loan>();
	public static int loanId = 1000;
	public static int customer_ID_Counter=100;
	 public static int getCustomerId() {
	    	return ++customer_ID_Counter;
	    }
	
	  public static int getCustomerID() { int custId = (int)
	  ((Math.random()*999)-1); return custId; }
	
	 public static int getLoanId() {
	    	return ++loanId;
	    }
}
