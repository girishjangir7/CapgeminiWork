package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exceptions.InvalidAmountException;
import com.capgemini.xyz.exceptions.InvalidDurationException;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.util.LoanDBUtil;

public class ExecuterMain {

	public static void main(String[] args) throws InvalidAmountException, InvalidDurationException {
		ILoanService service = new LoanService();
		Scanner sc =new Scanner(System.in);
		int index = 0;
		System.out.println("-----------------------:Welcome to the XYZ:-------------------------");
			System.out.println("Choose among the given options: ");
			System.out.println("1.Register the customer:");
			System.out.println("2.Exit:");
			index =sc.nextInt();
			switch(index) {
			case 1:
				try {
					System.out.println("Enter the customer name:");
					String name = sc.next();
					System.out.println("Enter the address:");
					String address = sc.next();
					System.out.println("Enter the customer email:");
					String email = sc.next();
					long mobile = 950117605;
					Customer customer = new Customer(name, address, email,mobile);
					service.insertCust(customer);
					
					System.out.println("Customer info saved succesfully");
					System.out.println("Your customer id "+ customer.getCustId());
					
				}catch(Exception e) {
						e.printStackTrace();
					}
				break;
			case 2: 
				System.out.println("Exit");
				System.exit(0);
				default:
					System.out.println("Invalid Option,Please Try Again!!!!!"); }
				System.out.println("---------------------------------------------------------------------------------------"); 
				System.out.println("Do you want to apply for loan?");
				System.out.println("1.Yes"); 
				System.out.println("2.No"); 
				int count =sc.nextInt();
				if(count==2) { 
					System.out.println(service.getAllCustomerDetails());
				}
				else { 
					System.out.println("Enter the loan amount: ");
					int amount = sc.nextInt();
					System.out.println("Enter the loan duration: ");
					int duration = sc.nextInt();
					Loan loan = new Loan(amount,duration);
					service.applyLoan(loan);
					double calcEmi= service.calculateEMI(amount, duration);
					System.out.println("For loan amount "+amount +" and "+ duration+" years ");
					System.out.println("Your emi per month will be: "+ calcEmi);
					System.out.println("Do you want to apply for loan?");
					System.out.println("1.Yes"); 
					System.out.println("2.No"); 
					int counter = sc.nextInt();
					if(counter==2) { 
						System.out.println(service.getAllCustomerDetails());
						
					}
					else {
						System.out.println("Your Loan request is generated!!!");
						System.out.println("Your loan id is: "+LoanDBUtil.getLoanId());
						System.out.println(service.getAllCustomerDetails());
						System.out.println(service.getAllLoanDetails());
					}
					}
				}

		}

	
