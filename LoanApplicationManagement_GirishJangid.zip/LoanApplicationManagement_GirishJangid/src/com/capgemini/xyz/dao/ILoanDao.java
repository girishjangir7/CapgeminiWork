package com.capgemini.xyz.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;


public interface ILoanDao {
public long applyLoan(Loan loan);
public long insertCust(Customer customer);
List <Customer> findAll();
List <Loan> findAllLoan();
}
