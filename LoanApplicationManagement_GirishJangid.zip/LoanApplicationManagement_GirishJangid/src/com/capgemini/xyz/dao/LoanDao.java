package com.capgemini.xyz.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.util.LoanDBUtil;


public class LoanDao implements ILoanDao{

	@Override
	public long applyLoan(Loan loan) {
	    loan.setLoanID(LoanDBUtil.getLoanId());
	    loan.setCustId(LoanDBUtil.customer_ID_Counter);
	    LoanDBUtil.loanEntry.put((int) loan.getLoanID(), loan);
		return loan.getLoanID();
	}

	@Override
	public long insertCust(Customer customer) {
		customer.setCustId(LoanDBUtil.customer_ID_Counter);
		LoanDBUtil.customerEntry.put((int) customer.getCustId(), customer);
		return customer.getCustId();
	}

	@Override
	public List<Customer> findAll() {
		
		return new ArrayList<Customer>(LoanDBUtil.customerEntry.values());
	}

	@Override
	public List<Loan> findAllLoan() {
		
		return new ArrayList<Loan>(LoanDBUtil.loanEntry.values());
	}

}
