package com.capgemini.xyz.exceptions;

public class InvalidAmountException extends Exception{

}
