package com.capgemini.xyz.exceptions;

public class InvalidEmailException extends Exception{

	public InvalidEmailException(String string) {
		// TODO Auto-generated constructor stub
	}

}
