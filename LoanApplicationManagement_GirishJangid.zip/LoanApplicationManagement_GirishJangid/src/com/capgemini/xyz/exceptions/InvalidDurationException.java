package com.capgemini.xyz.exceptions;

public class InvalidDurationException extends Exception {

}
