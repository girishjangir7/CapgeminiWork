package com.capgemini.xyz.exceptions;

public class InvalidCustomerNameException extends Exception{

	public InvalidCustomerNameException(String string) {
		// TODO Auto-generated constructor stub
	}

}
