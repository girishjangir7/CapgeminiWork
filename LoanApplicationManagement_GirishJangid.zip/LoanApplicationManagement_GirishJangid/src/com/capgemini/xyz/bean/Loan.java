package com.capgemini.xyz.bean;

public class Loan {
@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (custId ^ (custId >>> 32));
		result = prime * result + duration;
		long temp;
		temp = Double.doubleToLongBits(loanAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (int) (loanID ^ (loanID >>> 32));
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loan other = (Loan) obj;
		if (custId != other.custId)
			return false;
		if (duration != other.duration)
			return false;
		if (Double.doubleToLongBits(loanAmount) != Double.doubleToLongBits(other.loanAmount))
			return false;
		if (loanID != other.loanID)
			return false;
		return true;
	}
private long loanID,custId;
private double loanAmount;
private int duration;
public Loan() {
	super();
}



public Loan(long custId, double loanAmount, int duration) {
	super();
	this.custId = custId;
	this.loanAmount = loanAmount;
	this.duration = duration;
}



public Loan(long loanID, long custId, double loanAmount, int duration) {
	super();
	this.loanID = loanID;
	this.custId = custId;
	this.loanAmount = loanAmount;
	this.duration = duration;
}
public Loan(int loanAmount, int duration) {
	this.loanAmount = loanAmount;
	this.duration=duration;
}



public long getLoanID() {
	return loanID;
}
public void setLoanID(long loanID) {
	this.loanID = loanID;
}
public long getCustId() {
	return custId;
}
public void setCustId(long custId) {
	this.custId = custId;
}
public double getLoanAmount() {
	return loanAmount;
}
public void setLoanAmount(double loanAmount) {
	this.loanAmount = loanAmount;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
@Override
public String toString() {
	return "Loan [loanID=" + loanID + ", custId=" + custId + ", loanAmount=" + loanAmount + ", duration=" + duration
			+ "]";
}


}
