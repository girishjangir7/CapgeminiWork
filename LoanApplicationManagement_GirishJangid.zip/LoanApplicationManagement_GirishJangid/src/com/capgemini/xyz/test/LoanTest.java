package com.capgemini.xyz.test;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.util.LoanDBUtil;
public class LoanTest {
	private static LoanService services;

	@BeforeClass
	public static void setUpTestEnv() {
		services = new LoanService();
	}

	@Before
	public void setUpTestData() {
		Customer customer1 =new Customer(101, "Girish", "Pune", "girish@gmail.com", 950117605);
		Customer customer2 =new Customer(102, "Paras", "Pune2", "paras@gmail.com", 950605);
		LoanDBUtil.customerEntry.put((int) customer1.getCustId(),customer1);
		LoanDBUtil.customerEntry.put((int) customer2.getCustId(),customer2);
		
		LoanDBUtil.customer_ID_Counter=102;
	}

	
	 @After 
	 public void tearDownTestData() { 
		 LoanDBUtil.customerEntry.clear();
		 LoanDBUtil.customer_ID_Counter=100; 
	 }
	 /*
	 * @Test(expected=AssociateDetailNotFoundException.class) public void
	 * testCalculateNetSalaryForInvalidAssociateId() throws
	 * AssociateDetailNotFoundException { services.calculateNetSalary(1011); }
	 * 
	 * @Test public void testAcceptAssociateDetailsForValidData() { int
	 * expectedId=103; int actualId=services.acceptAssociateDetails("AB", "cd",
	 * "abc@xy", "department", "designation", "pancard", 100, 200, 10, 20, 12345,
	 * "bankName", "ifscCode"); Assert.assertEquals(expectedId, actualId); }
	 * 
	 * @Test(expected=AssociateDetailNotFoundException.class) public void
	 * testAcceptAssociateDetailsForInvalidData() throws
	 * AssociateDetailNotFoundException { services.getAssociateDetails(12343); }
	 * 
	 * @Test public void testCalculateNetSalaryForValidAssociateId() throws
	 * AssociateDetailNotFoundException { int expectedNetSalary = 0; int
	 * actualNetSalary=services.calculateNetSalary(101);
	 * Assert.assertEquals(expectedNetSalary, actualNetSalary); }
	 */
	@Test
	public void testGetAllCustomerDetails() {
		Customer customer1 =new Customer(101, "Girish", "Pune", "girish@gmail.com", 950117605);
		Customer customer2 =new Customer(102, "Paras", "Pune2", "paras@gmail.com", 950605);
		ArrayList <Customer> expectedAssociateList = new ArrayList<>();
		expectedAssociateList.add(customer1);
		expectedAssociateList.add(customer2);
		ArrayList <Customer> actualAssociateList = (ArrayList<Customer>) services.getAllCustomerDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}
	@AfterClass
	public static void tearDownEnv() {
		services=null;
	}

}
