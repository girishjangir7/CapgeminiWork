package com.cg.project.pagebeans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class Registration 
{
	@FindBy(how=How.NAME,name="Name")
	private WebElement name ;

	@FindBy(how=How.NAME,name="Address")
	private WebElement address;

	@FindBy(how=How.NAME,name="EMail")
	private WebElement email;


	@FindBy(how=How.NAME,name="Telephone")
	private WebElement telephone;

	@FindBy(how=How.NAME,name="Subject")
	private WebElement subject;

	@FindBy(how=How.NAME,name="Submit")
	private WebElement submit;
	
	public Registration() {}

	public Registration(WebElement name, WebElement address, WebElement email,
			WebElement telephone, WebElement subject, WebElement submit) {
		super();
		this.name = name;
		this.address = address;
		this.email = email;
		this.telephone = telephone;
		this.subject = subject;
		this.submit = submit;
	}

	public String getName() {
		return name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys("name");
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys("address");
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys("email");
	}


	public String getTelephone() {
		return telephone.getAttribute("value");
	}

	public void setTelephone(String telephone) {
		this.telephone.sendKeys("telephone");
	}

	public String getSubject() {
		return new Select(this.subject).getFirstSelectedOption().getText();
	}

	public void setSubject(String subject) {
		Select select=new Select(this.subject);
		select.selectByVisibleText(subject);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void signUp()
	{
		submit.submit();
	}

	
	
}
